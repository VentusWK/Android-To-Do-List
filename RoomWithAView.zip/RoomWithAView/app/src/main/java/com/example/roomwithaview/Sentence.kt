package com.example.roomwithaview

data class Sentence(var word:String)
